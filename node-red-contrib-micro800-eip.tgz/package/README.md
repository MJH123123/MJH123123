# node-red-contrib-micro800-eip

Dependency-free Node-RED nodes to read/write **Rockwell Micro800 (Micro820/830/850/870)** global variables over EtherNet/IP.

Unlike ControlLogix-oriented libraries, this one sends **no backplane/slot route path**. It talks to the
Message Router directly with unconnected explicit messaging, which is what Micro800 expects.
Uses only Node's built-in `net` module.

## Install
    cd ~/.node-red
    npm install /path/to/node-red-contrib-micro800-eip      # folder or .tgz from `npm pack`
Restart Node-RED. Nodes appear in the **Micro800** palette category.

## Nodes
- **micro800-config**: *Connection* tab (IP, port 44818, timeout, retry) and a *Variables* tab, the one place
  tags are entered: an editable, sortable list of `name | PLC tag | data type | elements`.
- **micro800-read**: *Single variable* (pick from list) or *All variables* (outputs `{name: value}`).
  Optional polling + "only on change". Override with `msg.variable`.
  Output `msg.payload`, `msg.topic`, `msg.dataType`.
- **micro800-write**: writes `msg.payload` to a variable from the list. Override with `msg.variable`.

## Tag syntax (Variables tab)
`MyVar`, `Struct.Member`, `Arr[3]`, `Arr[1,2]`. Set *Elements* > 1 to read an array slice from the tag.

## CCW requirements
- Variable must be **global** (not program-local).
- Set **External access / Visibility** to Read or Read/Write, rebuild, download to the PLC.
- Tag names are case-sensitive.

## Supported types
BOOL, SINT, INT, DINT, LINT, USINT, UINT, UDINT, ULINT, REAL, LREAL, STRING (short & u16-length).
User-defined structures are not supported; read their members individually (`Struct.Member`).

## Notes
- Requests are serialised over one TCP session, so the PLC sees a single CIP client.
- Close CCW or other clients if you hit connection limits.
- Verified against a mock PLC (`npm test`). Not yet verified on physical hardware, so if a STRING
  read/write misbehaves, try the other STRING type in the write node.
